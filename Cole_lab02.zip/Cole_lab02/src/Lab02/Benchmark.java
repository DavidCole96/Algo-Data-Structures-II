package Lab02;
import java.util.Scanner;
import java.util.Random;
import java.util.*;

public class Benchmark {

	public Benchmark() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("please enter a value for n");
		Random rand = new Random();
		Scanner scan = new Scanner(System.in);
		long n = scan.nextLong();
		long startTime = System.currentTimeMillis();
		for(int i=1; i <=10; i++)
		{
		
		double r = rand.nextLong()%(Math.pow(2,n));
		for(int z=1;z<r;z++)
		{
			long num1 = 192837465;
			long num2 = 293819475;
			long num3 = num1 * num2;
			long num4 = num1 * num2;
			long num5 = num1 * num2;
			long num6 = num1 * num2;
			long num7 = num1 * num2;
			long num8 = num1 * num2;
			long num9 = num1 * num2;
			long num10 = num1 * num2;
			long num11 = num1 * num2;
			long num12= num1 * num2;
			long num13= num1 * num2;
			long num14= num1 * num2;
			long num15= num1 * num2;
			long num16 = num1 * num2;
		

		}
		}
		long endTime   = System.currentTimeMillis();
		long totalTime = endTime - startTime;
		long average = totalTime/10;
		System.out.println(average);
	}

}
