
public class Recursion {
public static int factorial (int n){
	int x = n;
	int ans =1;
	if (n ==0){
		return 1;
	}
	else{
	ans = factorial(n-1)*n;
	return ans;
	}
}
public static int exponent(int b, int n){
	if (n == 0){
		return 1;
	}
	else 
			return b * exponent(b,n-1);
		}
public static int exponentTwo(int n){
	if(n>0)
		return (2*exponentTwo(n - 1));
	else
		return 1;
}
public static int logarithm(int b, int x){
	if(x <= b){
		return 1;
	}
	else{
		return logarithm(b, x/b)+1;
	}
}
public static int fib(int n){
	if (n ==0){
		return 0;
	}
	else if (n ==1){
		return 1;
	}
	else {
	return fib(n -1) + fib(n-2);
}
}
public static int mystery(int n){
	//odds doulbe even double -1
	
	if (n==1){
		return 1; //4 = 6
	}
	else{
		int x = mystery(n-1);
	
	if (n%2 ==0)
		return x + (x);
	else {
		return x + (x-1);
	}
	}
}
}


