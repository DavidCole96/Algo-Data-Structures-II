
public class RecursionDriver extends Recursion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("the factorial of 9 is:" + factorial(9));
		System.out.println("the exponent of 5^3 is:"+ exponent(5,3));
		System.out.println("2 to the 5th power is:"+exponentTwo(5));
		System.out.println("Log 2 10 (rounded) is equal to:"+logarithm(2,10));
		System.out.println("the thrid sequence in the fibonnaci code is: "+fib(3));
		System.out.println("mystery solution for 4th number in the sequence: "+ mystery(4));
	}

}
